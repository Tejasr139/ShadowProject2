import React from 'react';
import './OurServices.css';

const OurServices = () => {
  return (
    <div className="container">
      <h1>Our Services</h1>
      <p>This is the our services page.</p>
      <ul>
        <li>Service 1</li>
        <li>Service 2</li>
        <li>Service 3</li>
      </ul>
    </div>
  );
};

export default OurServices;