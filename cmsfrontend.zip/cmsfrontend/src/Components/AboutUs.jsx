import React from 'react';
import './About.css';



const AboutUs = () => {
  return (
    <div className="container">
      <h1>About Us</h1>
      <p>This is the about us page.</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sit amet nulla auctor, vestibulum magna sed, convallis ex.</p>
    </div>
  );
};

export default AboutUs;